﻿namespace FlightSimulatorApp.Views
{
    public partial class LonLat
    {
        public LonLat()
        {
            InitializeComponent();
        }
    }
}
